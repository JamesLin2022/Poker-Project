﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Localization;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SeedIdentity.Pages;

public class PrivacyModel : PageModel
{
    private readonly ILogger<PrivacyModel> _logger;

    private readonly IStringLocalizer<PrivacyModel> _localizer;
    private readonly IHtmlLocalizer<PrivacyModel> _htmlLocalizer;


    public PrivacyModel(ILogger<PrivacyModel> logger, 
        IStringLocalizer<PrivacyModel> localizer,
        IHtmlLocalizer<PrivacyModel> htmlLocalizer)
    {
        _logger = logger;
        _localizer = localizer;
        _htmlLocalizer = htmlLocalizer;
    }


    public void OnGet() {
        ViewData["Message"] = _localizer["Message"];
    }
}

