namespace SeedIdentity;
public class SharedResources {}