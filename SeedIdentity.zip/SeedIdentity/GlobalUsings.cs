global using System.Globalization;
global using Microsoft.Extensions.Options;
global using Microsoft.Extensions.Localization;
global using Microsoft.AspNetCore.Localization;
