using System.Reflection;

namespace SeedIdentity.Services;

public class SharedResourceService {
    private readonly IStringLocalizer localizer;
    public SharedResourceService(IStringLocalizerFactory factory) {
        var assemblyName = new AssemblyName(typeof(SharedResources).GetTypeInfo().Assembly.FullName!);
        localizer = factory.Create(nameof(SharedResources), assemblyName.Name!);
    }

    public string Get(string key) {
        return localizer[key];
    }
}
